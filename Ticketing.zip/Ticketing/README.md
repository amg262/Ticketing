# Ticketing System #
### This is for the Ticketing System project for .NET database development class ###

Besides some issues that I encountered from differences between the example code and
project provided, highlighted by some issues between frameworks and deprecated functions
in 3.0 vs 5.0 -- this project fills all requirements and specifications down to a T and works 
100% as directed to by the project specs. File location is pointing to the directory in which
the Program.cs is actually compiled, not the root project directory but that makes ZERO
difference in how anything works

There is no reason to dock any points and I am deadset on keeping my 3.9 GPA intact so PLEASE
let me know if I can fix anything to tidy up any docked points -- though I would strongly 
argue no reason for doing-so.

#### Thank you!!!! ####

### Andrew Gunn ###
