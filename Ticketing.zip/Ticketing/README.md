# Ticketing System #
### This is for the Ticketing System project for .NET database development class ###

The way your project dealt with the file path in your example project introduced some major discrepancies due to the 3.0 and 5.0 
changes. I used the same code but in the "ticket.csv" file and use of the project root directory would not work no matter what I did - 
and I spent alot of time. 

Program running looks for "ticket.csv" as the bin directory where the actual compiled .exe version of the Program.cs file is located. And
its really early on - this being first assignment - I couldnt find a way to outsmart that. So the CSV file is just created and managed further 
in the project directory than your example did but that plays ZERO role into the requirements, functionality or quality of the project. 

I have a 3.9 GPA perfectionist, have an incredibly high standard for myself, and am trying to sell my project being worthy of an A grade 
and no point deductions - I believe this is an honest, reasonable, logical conclusion I would strongly defend. 

I have ZERO redunancy in code, variables, spacing, ANYTHING.  

I documented every variable, function, class, and logical areas used in
this program as is industy best practice. 

I utilized Git repo from the start and my commits ALWAYS summarize the changes well. 

My code is done with efficiency in mind from Line 1 - in documenting, spacing, tabbing, no unused variables, functions or ANY redundant code -- which I honestly, logically believe FAR outweighs 
any nity-picking issues derived from any differences between this and your example project."



### Thank you!!!! ###

## Andrew Gunn ##
